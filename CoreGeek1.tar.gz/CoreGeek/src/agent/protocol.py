from dataclasses import dataclass, field
from typing import Any

DAY_ROUNDS = 70
NIGHT_ROUNDS = 60
ROUNDS_PER_DAY = DAY_ROUNDS + NIGHT_ROUNDS

WEAPON_BUILD_COST = 25
WALL_MATERIAL = "stone"
LAND = "land"
STATION = "station"
WALL = "wall"
WORKER = "worker"
PIONEER = "pioneer"
TOWER_TYPES = ("gatling", "railgun", "rocket")
CONTROLLABLE_TYPES = (WORKER, PIONEER)

# 武器等级→攻击距离
TOWER_RANGE_BY_LEVEL = {
    "gatling": (3, 5, 7),
    "railgun": (6, 8, 10),
    "rocket": (10, 15, 10**9),
}

# 矿石类型
MINE_TYPES = ("stone", "iron", "copper")

# 中立单位类型
VENDOR = "vendor"
WEAPON_SHOP = "weaponShop"

# 任务点类型
TASK_POINT_TYPES = (
    "challengerTaskPoint1",
    "challengerTaskPoint2",
    "defenderTaskPoint1",
    "defenderTaskPoint2",
)

# 武器商店商品价格
SHOP_PRICES = {
    "WeaponUpgradeVoucher1": 100,
    "WallUpgradeVoucher1": 20,
    "StationUpgradeVoucher1": 100,
    "WeaponUpgradeVoucher2": 150,
    "WallUpgradeVoucher2": 30,
    "StationUpgradeVoucher2": 150,
    "WallFixer": 10,
    "Medicine": 10,
    "DizzyWeapon": 100,
    "Bomb": 100,
    "SmallRobotSummonOrder": 20,
    "MiddleRobotSummonOrder": 30,
    "LargeRobotSummonOrder": 100,
    "BossRobotSummonOrder": 200,
    "AcientTablet": 15,
    "StarSand": 15,
    "FlameBreath": 15,
    "FrostPotion": 15,
    "ThornAmulet": 15,
    "IronWhistle": 15,
}

# 升级券名称
WEAPON_VOUCHERS = ("WeaponUpgradeVoucher1", "WeaponUpgradeVoucher2")
WALL_VOUCHERS = ("WallUpgradeVoucher1", "WallUpgradeVoucher2")
STATION_VOUCHERS = ("StationUpgradeVoucher1", "StationUpgradeVoucher2")

# 消耗品名称
CONSUMABLES = (
    "WallFixer", "Medicine", "DizzyWeapon", "Bomb",
    "SmallRobotSummonOrder", "MiddleRobotSummonOrder",
    "LargeRobotSummonOrder", "BossRobotSummonOrder",
)

# 任务用品名称
TASK_ITEMS = (
    "AcientTablet", "StarSand", "FlameBreath",
    "FrostPotion", "ThornAmulet", "IronWhistle",
)

# 矿石中文名映射
ORE_NAMES = {"stone": "石头", "iron": "铁", "copper": "铜"}

# 矿石→对应矿区类型
ORE_TO_MINE = {"stone": "stone", "iron": "iron", "copper": "copper"}


@dataclass(frozen=True, slots=True)
class Pos:
    x: int
    y: int

    @classmethod
    def load(cls, raw: Any) -> "Pos":
        return cls(int(raw["x"]), int(raw["y"]))

    def dump(self) -> dict[str, int]:
        return {"x": self.x, "y": self.y}


def distance(first: Pos, second: Pos) -> int:
    """切比雪夫距离"""
    return max(abs(first.x - second.x), abs(first.y - second.y))


def station_footprint(pos: Pos) -> tuple[Pos, ...]:
    """基地 2×2 占地，pos 为左上角"""
    return (
        pos,
        Pos(pos.x + 1, pos.y),
        Pos(pos.x, pos.y - 1),
        Pos(pos.x + 1, pos.y - 1),
    )


@dataclass(frozen=True, slots=True)
class Unit:
    unit_id: int
    pos: Pos
    kind: str
    health: int
    level: int
    cooldown: int
    attack_range: int
    attack_power: int
    capacity: int | None
    backpack: tuple[str, ...]

    @classmethod
    def load(cls, raw: dict[str, Any]) -> "Unit":
        raw_capacity = raw.get("backPackCapability")
        return cls(
            int(raw.get("id") or 0),
            Pos.load(raw["pos"]),
            str(raw["roleType"]),
            int(raw["health"]),
            int(raw.get("level") or 0),
            int(raw.get("cooldown") or 0),
            int(raw.get("attackRange") or 0),
            int(raw.get("attackPower") or 0),
            int(raw_capacity) if raw_capacity is not None else None,
            tuple(str(item) for item in raw.get("backpack") or ()),
        )

    @property
    def backpack_full(self) -> bool:
        if self.capacity is None:
            return False
        return len(self.backpack) >= self.capacity

    def range_of_attack(self) -> int:
        if self.attack_range > 0:
            return self.attack_range
        table = TOWER_RANGE_BY_LEVEL.get(self.kind)
        if table is None:
            return 0
        level = min(max(self.level, 1), len(table))
        return table[level - 1]

    def has_item(self, name: str) -> bool:
        return name in self.backpack

    def item_count(self, name: str) -> int:
        return self.backpack.count(name)


@dataclass(frozen=True, slots=True)
class Robot:
    robot_id: int
    pos: Pos
    health: int
    role_type: str
    abnormal_state: str
    target_team: str

    @classmethod
    def load(cls, raw: dict[str, Any]) -> "Robot":
        return cls(
            int(raw["id"]),
            Pos.load(raw["pos"]),
            int(raw["health"]),
            str(raw.get("roleType") or ""),
            str(raw.get("abnormalState") or ""),
            str(raw.get("targetTeam") or ""),
        )


@dataclass(frozen=True, slots=True)
class PlayerTask:
    task_type: str
    task_position: Pos
    cold_down_rounds: int
    score_reward: int
    gold_reward: int
    is_valid: bool
    timeout_rounds: int

    @classmethod
    def load(cls, raw: dict[str, Any]) -> "PlayerTask":
        return cls(
            str(raw.get("taskType") or ""),
            Pos.load(raw["taskPosition"]),
            int(raw.get("coldDownRounds") or 0),
            int(raw.get("scoreReward") or 0),
            int(raw.get("goldReward") or 0),
            bool(raw.get("isValid") or False),
            int(raw.get("timeoutRounds") or 0),
        )


@dataclass(frozen=True, slots=True)
class ShopItem:
    name: str
    price: int

    @classmethod
    def load(cls, raw: dict[str, Any]) -> "ShopItem":
        return cls(str(raw["name"]), int(raw["price"]))


@dataclass(frozen=True, slots=True)
class Turn:
    round_no: int
    is_day: bool
    gold: int
    total_score: int
    team_type: str
    width: int
    height: int
    zones: dict[Pos, str]
    ours: tuple[Unit, ...]
    enemies: tuple[Unit, ...]
    robots: tuple[Robot, ...]
    player_tasks: tuple[PlayerTask, ...]
    phase_task: str
    last_action_results: dict[int, bool]
    last_summon_treasure_result: int
    llm_resp: str
    world_news_official: str
    world_news_folk: str
    last_cmd_result: str
    vendor_shop_list: tuple[ShopItem, ...]
    weapon_shop_list: tuple[ShopItem, ...]
    errors: tuple[dict[str, Any], ...]

    @classmethod
    def load(cls, payload: dict[str, Any]) -> "Turn":
        round_no = int(payload["roundNo"])
        info = payload["mapInfo"]
        team = payload["teamOur"]
        enemy = payload.get("teamEnemy") or {}
        robot_data = payload.get("robot") or {}
        news = payload.get("worldNews") or {}

        return cls(
            round_no,
            (round_no - 1) % ROUNDS_PER_DAY < DAY_ROUNDS,
            int(team.get("goldNum") or 0),
            int(team.get("totalScore") or 0),
            str(team.get("type") or ""),
            int(info["width"]),
            int(info["height"]),
            {
                Pos.load(zone["pos"]): str(zone["neutralType"])
                for zone in info.get("zones") or ()
            },
            tuple(Unit.load(role) for role in team.get("roles") or ()),
            tuple(Unit.load(role) for role in enemy.get("roles") or ()),
            tuple(
                Robot.load(robot)
                for robot in robot_data.get("roles") or ()
            ),
            tuple(
                PlayerTask.load(task)
                for task in team.get("playerTasks") or ()
            ),
            str(payload.get("phaseTask") or ""),
            {
                int(k): bool(v)
                for k, v in (payload.get("lastRoundRoleActionResults") or {}).items()
            },
            int(payload.get("lastSummonTreasureResult") or 0),
            str(payload.get("llmResp") or ""),
            str(news.get("officialNews") or ""),
            str(news.get("folkLegends") or ""),
            str(payload.get("lastCmdResult") or ""),
            tuple(
                ShopItem.load(item) for item in (payload.get("vendorShopList") or ())
            ),
            tuple(
                ShopItem.load(item) for item in (payload.get("weaponShopList") or ())
            ),
            tuple(payload.get("errors") or ()),
        )

    # --- 己方单位查询 ---

    def station(self) -> Unit | None:
        for unit in self.ours:
            if unit.kind == STATION:
                return unit
        return None

    def alive(self, kinds: tuple[str, ...]) -> tuple[Unit, ...]:
        return tuple(
            unit for unit in self.ours
            if unit.kind in kinds and unit.health > 0
        )

    def controllable(self) -> tuple[Unit, ...]:
        return tuple(sorted(
            self.alive(CONTROLLABLE_TYPES), key=lambda unit: unit.unit_id,
        ))

    def workers(self) -> tuple[Unit, ...]:
        return tuple(sorted(
            self.alive((WORKER,)), key=lambda unit: unit.unit_id,
        ))

    def pioneer(self) -> Unit | None:
        for unit in self.alive((PIONEER,)):
            return unit
        return None

    def weapons(self) -> tuple[Unit, ...]:
        return tuple(sorted(
            self.alive(TOWER_TYPES),
            key=lambda unit: (unit.pos.x, unit.pos.y),
        ))

    def walls(self) -> tuple[Unit, ...]:
        return self.alive((WALL,))

    # --- 中立单位查询 ---

    def stone_mines(self) -> tuple[Pos, ...]:
        return tuple(
            pos for pos, kind in self.zones.items() if kind == "stone"
        )

    def iron_mines(self) -> tuple[Pos, ...]:
        return tuple(
            pos for pos, kind in self.zones.items() if kind == "iron"
        )

    def copper_mines(self) -> tuple[Pos, ...]:
        return tuple(
            pos for pos, kind in self.zones.items() if kind == "copper"
        )

    def all_mines(self) -> dict[Pos, str]:
        return {
            pos: kind for pos, kind in self.zones.items()
            if kind in MINE_TYPES
        }

    def vendors(self) -> tuple[Pos, ...]:
        return tuple(
            pos for pos, kind in self.zones.items() if kind == VENDOR
        )

    def weapon_shops(self) -> tuple[Pos, ...]:
        return tuple(
            pos for pos, kind in self.zones.items() if kind == WEAPON_SHOP
        )

    def task_points(self) -> tuple[Pos, ...]:
        """返回己方任务点坐标"""
        prefix = self.team_type if self.team_type else ""
        result = []
        for pos, kind in self.zones.items():
            if kind in TASK_POINT_TYPES and prefix and kind.startswith(prefix):
                result.append(pos)
        return tuple(result)

    # --- 地形与阻挡 ---

    def footprint(self, unit: Unit) -> tuple[Pos, ...]:
        if unit.kind == STATION:
            return station_footprint(unit.pos)
        return (unit.pos,)

    def land(self, pos: Pos) -> bool:
        if not 0 <= pos.x < self.width or not 0 <= pos.y < self.height:
            return False
        return self.zones.get(pos, LAND) == LAND

    def occupied_cells(self) -> frozenset[Pos]:
        cells: set[Pos] = set()
        for unit in self.ours:
            cells.update(self.footprint(unit))
        for unit in self.enemies:
            cells.update(self.footprint(unit))
        return frozenset(cells)

    def blocked(self, moving: Unit) -> frozenset[Pos]:
        cells = {pos for pos, kind in self.zones.items() if kind != LAND}
        cells.update(self.occupied_cells())
        cells.discard(moving.pos)
        for robot in self.robots:
            cells.add(robot.pos)
        return frozenset(cells)

    # --- 任务相关 ---

    def valid_task_points(self) -> tuple[PlayerTask, ...]:
        return tuple(task for task in self.player_tasks if task.is_valid)

    def mines_by_type(self, ore_type: str) -> tuple[Pos, ...]:
        """返回指定类型的矿区坐标"""
        return tuple(
            pos for pos, kind in self.zones.items() if kind == ore_type
        )

    def all_mine_positions(self) -> tuple[Pos, ...]:
        """返回所有矿区坐标"""
        return tuple(
            pos for pos, kind in self.zones.items() if kind in MINE_TYPES
        )

    def nearest_mine(self, origin: Pos, ore_type: str | None = None) -> Pos | None:
        """返回距 origin 最近的矿区，可指定矿石类型"""
        if ore_type:
            mines = self.mines_by_type(ore_type)
        else:
            mines = self.all_mine_positions()
        if not mines:
            return None
        return min(mines, key=lambda p: (distance(origin, p), p.x, p.y))

    def vendor_price(self, ore_name: str) -> int:
        """查询小贩对指定矿石的收购价，无数据时返回 0"""
        for item in self.vendor_shop_list:
            if item.name == ore_name:
                return item.price
        return 0


# --- 命令构造函数 ---

def move_command(pos: Pos) -> dict[str, Any]:
    return {"action": "move", "targetPos": [pos.dump()]}


def collect_command(pos: Pos) -> dict[str, Any]:
    return {"action": "collect", "targetPos": [pos.dump()]}


def build_command(pos: Pos, name: str) -> dict[str, Any]:
    return {"action": "build", "targetPos": [pos.dump()], "name": name}


def remove_command(pos: Pos) -> dict[str, Any]:
    return {"action": "remove", "targetPos": [pos.dump()]}


def attack_command(controller_id: int, targets: Pos | list[Pos]) -> dict[str, Any]:
    if isinstance(targets, Pos):
        target_list = [targets.dump()]
    else:
        target_list = [t.dump() for t in targets]
    return {
        "action": "attack",
        "targetPos": target_list,
        "controllerId": str(controller_id),
    }


def sell_command(name: str, num: int = 1) -> dict[str, Any]:
    cmd: dict[str, Any] = {"action": "sell", "name": name}
    if num != 1:
        cmd["num"] = num
    return cmd


def buy_command(name: str, num: int = 1) -> dict[str, Any]:
    cmd: dict[str, Any] = {"action": "buy", "name": name}
    if num != 1:
        cmd["num"] = num
    return cmd


def use_command(name: str, target_pos: Pos | None = None) -> dict[str, Any]:
    cmd: dict[str, Any] = {"action": "use", "name": name}
    if target_pos is not None:
        cmd["targetPos"] = [target_pos.dump()]
    return cmd


def drop_command(name: str) -> dict[str, Any]:
    return {"action": "drop", "name": name}


def accept_task_command() -> dict[str, Any]:
    return {"action": "acceptTask"}


def submit_answer_command(answer: str) -> dict[str, Any]:
    return {"action": "submitAnswer", "taskAnswer": answer}


def summon_treasure_command(target_pos: Pos, items: list[str]) -> dict[str, Any]:
    return {
        "action": "summonTreasure",
        "targetPos": [target_pos.dump()],
        "item": items,
    }
