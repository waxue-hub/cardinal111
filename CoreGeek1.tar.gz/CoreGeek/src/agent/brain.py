from typing import Any

from .grid import next_step
from .protocol import (
    CONSUMABLES,
    MINE_TYPES,
    ORE_NAMES,
    PIONEER,
    Pos,
    Turn,
    Unit,
    WALL,
    WALL_MATERIAL,
    WEAPON_BUILD_COST,
    WEAPON_VOUCHERS,
    WALL_VOUCHERS,
    STATION_VOUCHERS,
    TASK_ITEMS,
    TOWER_TYPES,
    VENDOR,
    WEAPON_SHOP,
    accept_task_command,
    attack_command,
    build_command,
    buy_command,
    collect_command,
    distance,
    drop_command,
    move_command,
    remove_command,
    sell_command,
    station_footprint,
    submit_answer_command,
    summon_treasure_command,
    use_command,
)

TOWER_LOADOUT = ("gatling", "railgun", "rocket")
STONE_BATCH = 6
_NEIGHBOUR_STEPS = (
    (-1, -1), (-1, 0), (-1, 1),
    (0, -1), (0, 1),
    (1, -1), (1, 0), (1, 1),
)

# 开拓者任务状态（跨回合持久化）
_pioneer_state: dict[str, Any] = {
    "has_task": False,
    "task_round": 0,
    "task_point_idx": 0,
    "sandbox_cmd_sent": False,
    "sandbox_results": [],
    "task_answers": [],
    "task_phase": "idle",  # idle → exploring → querying_llm → answering → done
    "explore_cmd_count": 0,
    "best_answer": "",
    "best_pass_rate": 0.0,
    "skill_library": {},   # 任务关键词 → {cmd: str, result: str, answer: str}
    "current_task_key": "",  # 当前任务的关键标识
    "last_sandbox_cmd": "",  # 最后发出的沙盒命令
    "task_cooldown": 0,      # 任务失败后冷却回合数
    "pending_skill": None,   # 待确认的 SKILL 记录（提交答案后等待验证）
    "task_fail_counts": {},  # task_key → 连续失败次数
    "task_key_cooldown": {}, # task_key → 该任务专属冷却剩余回合数
}

# 宝藏状态（跨回合持久化）
_treasure_state: dict[str, Any] = {
    "found": False,
    "altar_pos": None,
    "required_items": [],
    "collected_clues": [],
    "summoned": False,
}

# 经济状态（跨回合持久化）
_economy_state: dict[str, Any] = {
    "price_trends": {},
    "sell_priority": "stone",
}

# 升级追踪（跨回合持久化）
_upgrade_state: dict[str, Any] = {
    "weapon_levels": {},  # pos -> level
    "wall_upgraded": set(),
    "station_upgraded": False,
    "station_upgrade_level": 1,
}

# 召唤令使用追踪（跨回合持久化）
_summon_order_state: dict[str, Any] = {
    "daily_count": 0,       # 当天已使用召唤令数
    "last_day": 0,          # 上次使用时的天数
}


def _handle_errors(turn: Turn) -> None:
    """检查 errors 数组，处理任务超时/答案错误/LLM 额度超限"""
    has_error_2 = False
    for err in turn.errors:
        code = int(err.get("errorCode") or 0)
        if code == 1:
            # 任务超时：重置开拓者状态
            _pioneer_state["has_task"] = False
            _pioneer_state["task_phase"] = "idle"
            _pioneer_state["sandbox_cmd_sent"] = False
            _pioneer_state["sandbox_results"] = []
            _pioneer_state["explore_cmd_count"] = 0
            _pioneer_state["last_sandbox_cmd"] = ""
            _pioneer_state["pending_skill"] = None
        elif code == 2:
            # 答案错误：丢弃待确认的 SKILL 记录，重置任务状态以重新接取
            has_error_2 = True
            task_key = _pioneer_state.get("current_task_key", "")
            _pioneer_state["has_task"] = False
            _pioneer_state["task_phase"] = "idle"
            _pioneer_state["sandbox_cmd_sent"] = False
            _pioneer_state["sandbox_results"] = []
            _pioneer_state["explore_cmd_count"] = 0
            _pioneer_state["last_sandbox_cmd"] = ""
            _pioneer_state["pending_skill"] = None
            _pioneer_state["task_cooldown"] = 15
            if task_key:
                fail_counts = _pioneer_state.get("task_fail_counts", {})
                fail_count = fail_counts.get(task_key, 0) + 1
                fail_counts[task_key] = fail_count
                _pioneer_state["task_fail_counts"] = fail_counts
                key_cd = _pioneer_state.get("task_key_cooldown", {})
                if fail_count >= 2:
                    key_cd[task_key] = 50
                else:
                    key_cd[task_key] = 15
                _pioneer_state["task_key_cooldown"] = key_cd
        elif code == 5:
            # LLM 额度超限：跳过 LLM 阶段，直接用沙盒结果作答
            if _pioneer_state.get("task_phase") == "querying_llm":
                _pioneer_state["task_phase"] = "answering"

    # 没有错误且有待确认的 SKILL 记录 → 答案正确，正式写入 SKILL 库
    if not has_error_2 and not turn.errors and _pioneer_state.get("pending_skill"):
        pending = _pioneer_state["pending_skill"]
        key = pending.get("task_key", "")
        if key:
            _pioneer_state["skill_library"][key] = {
                "cmd": pending.get("cmd", ""),
                "result": pending.get("result", ""),
                "answer": pending.get("answer", ""),
            }
        _pioneer_state["pending_skill"] = None


def decide(payload: dict[str, Any]) -> dict[str, Any]:
    """返回完整 Response：roleCommandMap / prompt / executeCmd"""
    turn = Turn.load(payload)
    _handle_errors(turn)

    commands: dict[int, dict[str, Any]] = {}
    prompt = ""
    execute_cmd = ""

    if turn.is_day:
        _day(turn, commands)
        # 沙盒交互：开拓者任务期间构造 executeCmd 和 prompt
        if _pioneer_state["has_task"] and turn.phase_task:
            if turn.last_cmd_result and turn.last_cmd_result.strip():
                _pioneer_state["sandbox_results"].append(turn.last_cmd_result)
            execute_cmd, prompt = _build_task_interaction(turn)
    else:
        _night(turn, commands)

    return {
        "roleCommandMap": {str(key): value for key, value in commands.items()},
        "prompt": prompt,
        "executeCmd": execute_cmd,
    }


def _pioneer_extras(
    turn: Turn,
    pioneer: Unit,
    commands: dict[int, dict[str, Any]],
) -> None:
    """开拓者新增功能：血量低治疗、召唤宝藏"""
    # 血量低时使用生命药剂
    if pioneer.health < 100 and pioneer.has_item("Medicine"):
        commands[pioneer.unit_id] = use_command("Medicine")
        return

    # 召唤宝藏
    if (
        _treasure_state.get("found")
        and not _treasure_state.get("summoned")
        and _treasure_state.get("required_items")
    ):
        all_backpacks = list(pioneer.backpack)
        for u in turn.workers():
            all_backpacks.extend(u.backpack)
        has_all_items = all(
            item in all_backpacks for item in _treasure_state["required_items"]
        )
        if has_all_items:
            altar = _treasure_state.get("altar_pos")
            if altar is not None:
                if distance(pioneer.pos, altar) <= 1:
                    commands[pioneer.unit_id] = summon_treasure_command(
                        altar, _treasure_state["required_items"],
                    )
                    _treasure_state["summoned"] = True
                    return
                step = _step_toward(turn, pioneer, altar, set())
                if step is not None:
                    commands[pioneer.unit_id] = move_command(step)
                    return


def _mine_other_ores(
    turn: Turn,
    role: Unit,
    commands: dict[int, dict[str, Any]],
    claimed: set[Pos] | None = None,
) -> None:
    """采集铁矿/铜矿，根据价格趋势优先采集涨价矿石"""
    if role.backpack_full:
        return
    if claimed is None:
        claimed = set()
    # 根据价格趋势排序矿种（涨价优先）
    trends = _economy_state.get("price_trends", {})
    ore_priority = sorted(
        ("iron", "copper"),
        key=lambda ore: -trends.get(ore, 1.0),
    )
    for ore_type in ore_priority:
        mines = sorted(
            (pos for pos in turn.mines_by_type(ore_type) if pos not in claimed),
            key=lambda pos: (distance(role.pos, pos), pos.x, pos.y),
        )
        for mine in mines:
            if distance(role.pos, mine) <= 1:
                commands[role.unit_id] = collect_command(mine)
                claimed.add(mine)
                return
        if mines:
            nearest = mines[0]
            if distance(role.pos, nearest) <= 3:
                step = _step_toward(turn, role, nearest, claimed)
                if step is not None:
                    commands[role.unit_id] = move_command(step)
                    return


def _night_heal(turn: Turn, commands: dict[int, dict[str, Any]]) -> None:
    """夜晚紧急治疗：血量危险的角色优先治疗，覆盖武器操作"""
    for role in turn.controllable():
        if role.unit_id in commands:
            continue
        if role.health < 60 and role.has_item("Medicine"):
            commands[role.unit_id] = use_command("Medicine")
            return


def _night_extras(turn: Turn, commands: dict[int, dict[str, Any]]) -> None:
    """夜晚新增功能：对未被分配指令的角色使用消耗品"""
    robots = turn.robots
    if not robots:
        return

    current_day = (turn.round_no - 1) // 130 + 1
    if _summon_order_state["last_day"] != current_day:
        _summon_order_state["daily_count"] = 0
        _summon_order_state["last_day"] = current_day
    daily_remaining = 10 - _summon_order_state["daily_count"]

    avg_x = sum(r.pos.x for r in robots) / len(robots)
    avg_y = sum(r.pos.y for r in robots) / len(robots)
    cluster_pos = Pos(int(avg_x), int(avg_y))

    for role in turn.controllable():
        if role.unit_id in commands:
            continue
        if role.has_item("Bomb") and len(robots) >= 3:
            commands[role.unit_id] = use_command("Bomb", cluster_pos)
            return
        if role.has_item("DizzyWeapon") and len(robots) >= 5:
            commands[role.unit_id] = use_command("DizzyWeapon", cluster_pos)
            return
        if daily_remaining > 0:
            for item_name in (
                "BossRobotSummonOrder", "LargeRobotSummonOrder",
                "MiddleRobotSummonOrder", "SmallRobotSummonOrder",
            ):
                if role.has_item(item_name):
                    commands[role.unit_id] = use_command(item_name)
                    _summon_order_state["daily_count"] += 1
                    return
        if role.health < 80 and role.has_item("Medicine"):
            commands[role.unit_id] = use_command("Medicine")
            return


# ==================== 白天策略 ====================

def _day(turn: Turn, commands: dict[int, dict[str, Any]]) -> None:
    sites = _tower_sites(turn)
    order = _wall_order(turn)
    standing_towers = {unit.pos for unit in turn.weapons()}
    standing_walls = {unit.pos for unit in turn.walls()}
    occupied = turn.occupied_cells()
    towers_missing = [pos for pos in sites if pos not in standing_towers]
    walls_missing = [pos for pos in order if pos not in standing_walls]
    free_towers = [pos for pos in towers_missing if pos not in occupied]
    free_walls = [pos for pos in walls_missing if pos not in occupied]

    # 解析世界新闻
    _analyse_world_news(turn)

    claimed: set[Pos] = set()
    for role in turn.workers():
        _worker_day(
            turn, role, sites, free_towers, free_walls, claimed, commands,
        )

    # 开拓者白天前往任务点领任务/提交答案/召唤宝藏
    pioneer = turn.pioneer()
    if pioneer is not None:
        _pioneer_day(turn, pioneer, commands)


def _worker_day(
    turn: Turn,
    role: Unit,
    sites: tuple[Pos, ...],
    towers_missing: list[Pos],
    walls_missing: list[Pos],
    claimed: set[Pos],
    commands: dict[int, dict[str, Any]],
) -> None:
    ores = _count_ores(role)

    # 1. 建造武器工事（优先）
    if towers_missing and turn.gold >= WEAPON_BUILD_COST:
        for index, site in enumerate(sites):
            if site in towers_missing and site not in claimed:
                _build_or_walk(
                    turn, role, site, TOWER_LOADOUT[index], claimed, commands,
                )
                return

    # 2. 建造围墙（围墙优先于卖矿）
    if walls_missing:
        stones = role.backpack.count(WALL_MATERIAL)
        mine = _adjacent_mine(turn, role)
        if mine is not None and stones < STONE_BATCH:
            commands[role.unit_id] = collect_command(mine)
            claimed.add(mine)
            return
        if stones:
            for site in walls_missing:
                if site not in claimed:
                    _build_or_walk(turn, role, site, WALL, claimed, commands)
                    return
        if _mine(turn, role, claimed, commands):
            return
        # 无石矿可采时，尝试采铁铜矿或买消耗品
        _mine_other_ores(turn, role, commands, claimed)
        if role.unit_id in commands:
            return

    # 3. 围墙建完后，背包满时去卖矿（按实时收购价优先卖出高价矿石）
    if ores and role.backpack_full:
        vendor = _nearest(turn, role.pos, turn.vendors())
        if vendor is not None:
            if distance(role.pos, vendor) <= 1:
                # 按 vendorShopList 实时价格 + 价格趋势排序，优先卖高价矿石
                priced = []
                for ore_name, count in ores.items():
                    if count <= 0:
                        continue
                    base_price = turn.vendor_price(ore_name)
                    trend = _economy_state.get("price_trends", {}).get(ore_name, 1.0)
                    effective_price = base_price * trend if base_price else 0
                    priced.append((ore_name, count, effective_price))
                priced.sort(key=lambda x: -x[2])
                if priced:
                    best_ore, best_count, _ = priced[0]
                    commands[role.unit_id] = sell_command(best_ore, best_count)
                    return
            step = _step_toward(turn, role, vendor, claimed)
            if step is not None:
                commands[role.unit_id] = move_command(step)
                return

    # 4. 新增功能
    # 4a. 建造全部完成后才尝试升级类操作
    if not towers_missing and not walls_missing:
        _try_upgrade_weapon(turn, role, commands)
        if role.unit_id in commands:
            return
        _try_upgrade_station(turn, role, commands)
        if role.unit_id in commands:
            return
        _try_upgrade_walls(turn, role, commands)
        if role.unit_id in commands:
            return
        _try_fix_walls(turn, role, commands)
        if role.unit_id in commands:
            return

    # 4b. 不依赖建造完成的操作：购买任务用品、购买消耗品、拆除围墙、采铁铜矿
    _try_buy_task_items(turn, role, commands)
    if role.unit_id in commands:
        return
    _try_buy_consumables(turn, role, commands)
    if role.unit_id in commands:
        return
    _try_remove_blocking_wall(turn, role, commands)
    if role.unit_id in commands:
        return
    _mine_other_ores(turn, role, commands, claimed)
    if role.unit_id in commands:
        return

    # 背包满时丢弃低价值物品腾出空间
    if role.backpack_full and role.unit_id not in commands:
        _drop_low_value(turn, role, commands)
        return

    # 5. 原始回退：继续采集石矿
    if _mine(turn, role, claimed, commands):
        return

    # 所有矿都不可达时，走向最近矿区方向（排除已被其他角色占用的矿）
    all_mines = [pos for pos in turn.all_mine_positions() if pos not in claimed]
    if all_mines:
        nearest = min(all_mines, key=lambda p: (distance(role.pos, p), p.x, p.y))
        step = _step_toward(turn, role, nearest, claimed)
        if step is not None:
            commands[role.unit_id] = move_command(step)
            return

    # 完全无路可走时，向基地靠拢
    station = turn.station()
    if station is not None and distance(role.pos, station.pos) > 2:
        step = _step_toward(turn, role, station.pos, claimed)
        if step is not None:
            commands[role.unit_id] = move_command(step)


def _mine(
    turn: Turn,
    role: Unit,
    claimed: set[Pos],
    commands: dict[int, dict[str, Any]],
) -> bool:
    if role.backpack_full:
        return False
    # 按最近距离排序所有石矿
    mines = sorted(
        (pos for pos in turn.stone_mines() if pos not in claimed),
        key=lambda pos: (distance(role.pos, pos), pos.x, pos.y),
    )
    if not mines:
        return False
    # 优先处理相邻可采集的石矿
    for mine in mines:
        if distance(role.pos, mine) <= 1:
            commands[role.unit_id] = collect_command(mine)
            claimed.add(mine)
            return True
    # 没有相邻石矿：如果旁边有其他矿（铁/铜），先采集不空跑
    for ore_type in ("iron", "copper"):
        for ore_pos in turn.mines_by_type(ore_type):
            if distance(role.pos, ore_pos) <= 1 and ore_pos not in claimed:
                commands[role.unit_id] = collect_command(ore_pos)
                claimed.add(ore_pos)
                return True
    # 走向最近的可达石矿
    for nearest in mines:
        step = _step_toward(turn, role, nearest, claimed)
        if step is not None:
            commands[role.unit_id] = move_command(step)
            return True
    return False


# ==================== 升级逻辑 ====================

def _try_upgrade_weapon(
    turn: Turn,
    role: Unit,
    commands: dict[int, dict[str, Any]],
) -> bool:
    """尝试升级武器工事"""
    weapons = turn.weapons()
    for weapon in weapons:
        if weapon.level >= 3:
            continue
        # 判断需要哪种升级券
        if weapon.level == 1:
            voucher = "WeaponUpgradeVoucher1"
            cost = 100
        else:
            voucher = "WeaponUpgradeVoucher2"
            cost = 150

        # 检查是否已有券
        has_voucher = role.has_item(voucher)
        if not has_voucher and turn.gold < cost:
            continue

        # 需要在武器旁边使用
        if distance(role.pos, weapon.pos) <= 1:
            if has_voucher:
                commands[role.unit_id] = use_command(voucher, weapon.pos)
                return True
            # 去武器商店购买
            if turn.gold >= cost and _shop_has_item(turn, voucher):
                shop = _nearest(turn, role.pos, turn.weapon_shops())
                if shop is not None and distance(role.pos, shop) <= 1:
                    commands[role.unit_id] = buy_command(voucher)
                    return True
                step = _step_toward(turn, role, shop, set())
                if step is not None:
                    commands[role.unit_id] = move_command(step)
                    return True
        else:
            # 走向武器
            if has_voucher:
                step = _step_toward(turn, role, weapon.pos, set())
                if step is not None:
                    commands[role.unit_id] = move_command(step)
                    return True
            else:
                # 先去商店买券
                if turn.gold >= cost and _shop_has_item(turn, voucher):
                    shop = _nearest(turn, role.pos, turn.weapon_shops())
                    if shop is not None:
                        if distance(role.pos, shop) <= 1:
                            commands[role.unit_id] = buy_command(voucher)
                            return True
                        step = _step_toward(turn, role, shop, set())
                        if step is not None:
                            commands[role.unit_id] = move_command(step)
                            return True
    return False


def _try_upgrade_station(
    turn: Turn,
    role: Unit,
    commands: dict[int, dict[str, Any]],
) -> bool:
    """尝试升级基地"""
    station = turn.station()
    if station is None or station.level >= 3:
        return False

    current_level = _upgrade_state.get("station_upgrade_level", 1)
    if current_level >= 3:
        return False

    if current_level == 1:
        voucher = "StationUpgradeVoucher1"
        cost = 100
    else:
        voucher = "StationUpgradeVoucher2"
        cost = 150

    has_voucher = role.has_item(voucher)
    if not has_voucher and turn.gold < cost:
        return False

    footprint = station_footprint(station.pos)

    # 在基地旁使用
    if _footprint_distance(role.pos, footprint) <= 1:
        if has_voucher:
            commands[role.unit_id] = use_command(voucher, station.pos)
            _upgrade_state["station_upgrade_level"] = current_level + 1
            return True
        if turn.gold >= cost:
            shop = _nearest(turn, role.pos, turn.weapon_shops())
            if shop is not None and distance(role.pos, shop) <= 1:
                commands[role.unit_id] = buy_command(voucher)
                return True
            step = _step_toward(turn, role, shop, set())
            if step is not None:
                commands[role.unit_id] = move_command(step)
                return True
    else:
        if has_voucher:
            step = _step_toward(turn, role, station.pos, set())
            if step is not None:
                commands[role.unit_id] = move_command(step)
                return True
        elif turn.gold >= cost:
            shop = _nearest(turn, role.pos, turn.weapon_shops())
            if shop is not None:
                if distance(role.pos, shop) <= 1:
                    commands[role.unit_id] = buy_command(voucher)
                    return True
                step = _step_toward(turn, role, shop, set())
                if step is not None:
                    commands[role.unit_id] = move_command(step)
                    return True
    return False


def _try_upgrade_walls(
    turn: Turn,
    role: Unit,
    commands: dict[int, dict[str, Any]],
) -> bool:
    """尝试升级围墙"""
    walls = turn.walls()
    upgraded_set = _upgrade_state.get("wall_upgraded", set())

    for wall in walls:
        if wall.level >= 3:
            continue
        wall_key = (wall.pos.x, wall.pos.y)
        if wall_key in upgraded_set:
            continue

        if wall.level == 1:
            voucher = "WallUpgradeVoucher1"
            cost = 20
        else:
            voucher = "WallUpgradeVoucher2"
            cost = 30

        has_voucher = role.has_item(voucher)
        if not has_voucher and turn.gold < cost:
            continue

        if distance(role.pos, wall.pos) <= 1:
            if has_voucher:
                commands[role.unit_id] = use_command(voucher, wall.pos)
                upgraded_set.add(wall_key)
                _upgrade_state["wall_upgraded"] = upgraded_set
                return True
            if turn.gold >= cost:
                shop = _nearest(turn, role.pos, turn.weapon_shops())
                if shop is not None and distance(role.pos, shop) <= 1:
                    commands[role.unit_id] = buy_command(voucher)
                    return True
                step = _step_toward(turn, role, shop, set())
                if step is not None:
                    commands[role.unit_id] = move_command(step)
                    return True
        else:
            if has_voucher:
                step = _step_toward(turn, role, wall.pos, set())
                if step is not None:
                    commands[role.unit_id] = move_command(step)
                    return True
            elif turn.gold >= cost:
                shop = _nearest(turn, role.pos, turn.weapon_shops())
                if shop is not None:
                    if distance(role.pos, shop) <= 1:
                        commands[role.unit_id] = buy_command(voucher)
                        return True
                    step = _step_toward(turn, role, shop, set())
                    if step is not None:
                        commands[role.unit_id] = move_command(step)
                        return True
    return False


def _try_fix_walls(
    turn: Turn,
    role: Unit,
    commands: dict[int, dict[str, Any]],
) -> bool:
    """修复受损围墙（血量不满的围墙）"""
    walls = turn.walls()
    max_wall_hp = {1: 200, 2: 400, 3: 600}

    for wall in walls:
        max_hp = max_wall_hp.get(wall.level, 200)
        if wall.health >= max_hp:
            continue

        has_fixer = role.has_item("WallFixer")
        if not has_fixer and turn.gold < 10:
            continue

        if distance(role.pos, wall.pos) <= 1:
            if has_fixer:
                commands[role.unit_id] = use_command("WallFixer", wall.pos)
                return True
            if turn.gold >= 10:
                shop = _nearest(turn, role.pos, turn.weapon_shops())
                if shop is not None and distance(role.pos, shop) <= 1:
                    commands[role.unit_id] = buy_command("WallFixer")
                    return True
                step = _step_toward(turn, role, shop, set())
                if step is not None:
                    commands[role.unit_id] = move_command(step)
                    return True
        else:
            if has_fixer:
                step = _step_toward(turn, role, wall.pos, set())
                if step is not None:
                    commands[role.unit_id] = move_command(step)
                    return True
    return False


# ==================== 消耗品逻辑 ====================

def _try_buy_consumables(
    turn: Turn,
    role: Unit,
    commands: dict[int, dict[str, Any]],
) -> bool:
    """购买关键消耗品"""
    needed = []

    # 生命药剂：角色血量低于50%时购买
    pioneer = turn.pioneer()
    if pioneer is not None and pioneer.health < 100 and not pioneer.has_item("Medicine"):
        needed.append(("Medicine", 10))

    for worker in turn.workers():
        if worker.health < 110 and not worker.has_item("Medicine"):
            needed.append(("Medicine", 10))

    # 眩晕法宝：夜晚防御用
    has_dizzy = any(u.has_item("DizzyWeapon") for u in turn.alive(("worker", "pioneer")))
    if not has_dizzy and turn.gold >= 100:
        needed.append(("DizzyWeapon", 100))

    # 范围炸弹：夜晚防御用
    has_bomb = any(u.has_item("Bomb") for u in turn.alive(("worker", "pioneer")))
    if not has_bomb and turn.gold >= 100:
        needed.append(("Bomb", 100))

    # 机器人召唤令：给对方施压（每天最多10张）
    current_day = (turn.round_no - 1) // 130 + 1
    if _summon_order_state["last_day"] != current_day:
        _summon_order_state["daily_count"] = 0
        _summon_order_state["last_day"] = current_day
    daily_used = _summon_order_state["daily_count"]
    daily_remaining = 10 - daily_used

    if daily_remaining > 0:
        if turn.gold >= 200:
            has_boss = any(u.has_item("BossRobotSummonOrder") for u in turn.alive(("worker", "pioneer")))
            if not has_boss:
                needed.append(("BossRobotSummonOrder", 200))
        if turn.gold >= 100:
            has_large = any(u.has_item("LargeRobotSummonOrder") for u in turn.alive(("worker", "pioneer")))
            if not has_large:
                needed.append(("LargeRobotSummonOrder", 100))
        if turn.gold >= 30:
            has_middle = any(u.has_item("MiddleRobotSummonOrder") for u in turn.alive(("worker", "pioneer")))
            if not has_middle:
                needed.append(("MiddleRobotSummonOrder", 30))
        if turn.gold >= 20:
            has_small = any(u.has_item("SmallRobotSummonOrder") for u in turn.alive(("worker", "pioneer")))
            if not has_small:
                needed.append(("SmallRobotSummonOrder", 20))

    if not needed:
        return False

    # 按金币排序，优先买便宜的
    needed.sort(key=lambda x: x[1])
    for item_name, cost in needed:
        if turn.gold < cost:
            continue
        if not _shop_has_item(turn, item_name):
            continue
        shop = _nearest(turn, role.pos, turn.weapon_shops())
        if shop is None:
            return False
        if distance(role.pos, shop) <= 1:
            commands[role.unit_id] = buy_command(item_name)
            return True
        step = _step_toward(turn, role, shop, set())
        if step is not None:
            commands[role.unit_id] = move_command(step)
            return True
    return False


def _try_buy_task_items(
    turn: Turn,
    role: Unit,
    commands: dict[int, dict[str, Any]],
) -> bool:
    """购买任务用品（为召唤宝藏做准备）"""
    required = _treasure_state.get("required_items", [])
    if not required:
        return False

    # 检查已有任务用品
    all_backpacks = []
    for u in turn.alive(("worker", "pioneer")):
        all_backpacks.extend(u.backpack)

    for item in required:
        if item not in all_backpacks and turn.gold >= 15:
            if not _shop_has_item(turn, item):
                continue
            shop = _nearest(turn, role.pos, turn.weapon_shops())
            if shop is None:
                return False
            if distance(role.pos, shop) <= 1:
                commands[role.unit_id] = buy_command(item)
                return True
            step = _step_toward(turn, role, shop, set())
            if step is not None:
                commands[role.unit_id] = move_command(step)
                return True
    return False


# ==================== 世界新闻分析 ====================

def _analyse_world_news(turn: Turn) -> None:
    """解析世界新闻，更新经济状态和宝藏状态"""
    official = turn.world_news_official
    folk = turn.world_news_folk

    # 解析官方消息对矿石价格的影响
    if official:
        trends = _economy_state.get("price_trends", {})
        news_lower = official.lower()

        # 检测矿石关键词和涨跌趋势
        ore_keywords = {
            "stone": ["石头", "石矿", "石材"],
            "iron": ["铁", "铁矿"],
            "copper": ["铜", "铜矿"],
        }

        for ore, keywords in ore_keywords.items():
            for kw in keywords:
                if kw in news_lower:
                    # 检测涨价/稀缺关键词
                    if any(w in news_lower for w in ["上涨", "稀缺", "停工", "塌方", "短缺", "上涨"]):
                        trends[ore] = 1.5
                    elif any(w in news_lower for w in ["恢复", "下跌", "过剩", "供过于求"]):
                        trends[ore] = 0.8
                    break
        _economy_state["price_trends"] = trends

    # 解析民间传闻，收集线索
    if folk:
        clues = _treasure_state.get("collected_clues", [])
        if folk not in clues:
            clues.append(folk)
            _treasure_state["collected_clues"] = clues

        # 尝试从传闻中提取宝藏信息
        _parse_treasure_clues(turn)


def _parse_treasure_clues(turn: Turn) -> None:
    """从民间传闻线索中推断宝藏信息"""
    clues = _treasure_state.get("collected_clues", [])
    if len(clues) < 2:
        return

    # 合并所有线索文本
    full_text = " ".join(clues)

    # 推断宝藏所需物品
    item_keywords = {
        "AcientTablet": ["古符石板", "石板", "远古文字"],
        "StarSand": ["星辰之沙", "银白色", "细沙"],
        "FlameBreath": ["烈焰之息", "橙红色", "雾气"],
        "FrostPotion": ["寒霜药剂", "深蓝色", "薄霜"],
        "ThornAmulet": ["荆棘护符", "藤蔓", "尖刺"],
        "IronWhistle": ["回音铁哨", "生铁", "哨子"],
    }

    required = []
    for item, keywords in item_keywords.items():
        for kw in keywords:
            if kw in full_text:
                required.append(item)
                break

    if required:
        _treasure_state["required_items"] = required

    # 推断祭坛位置（从线索中提取坐标信息）
    if "altar_pos" not in _treasure_state or _treasure_state["altar_pos"] is None:
        # 尝试从任务点附近寻找祭坛
        task_points = turn.task_points()
        if task_points:
            _treasure_state["altar_pos"] = task_points[0]

    _treasure_state["found"] = len(required) > 0


# ==================== 开拓者策略 ====================

def _extract_task_key(task_desc: str) -> str:
    """从任务描述中提取关键标识，用于 SKILL 库匹配"""
    import re
    # 提取任务描述中前 50 个字符的关键词作为标识
    cleaned = re.sub(r'[^\w一-鿿]', '', task_desc)[:50]
    return cleaned


_INVALID_ANSWER_PATTERNS = (
    "No such file",
    "文件不存在",
    "文件缺失",
    "无法执行",
    "无法获取",
    "无法从该文件",
    "请确认文件",
    "任务文件缺失",
    "not found",
    "does not exist",
)

_INVALID_ANSWER_HINTS = (
    "我将首先",
    "我将模拟",
    "我需要执行",
    "请执行",
    "请你提供",
    "请确认",
    "由于我无法",
    "waiting_for_check",
    "waiting",
    "需要执行修复后",
    "需要在沙盒",
    "建议将",
    "如果你能提供",
    "如果你希望",
    "### 解题步骤",
    "#### 第一步",
    "#### 第二步",
    "解题框架",
    "修复指南",
    "标准解题",
    "假设性示例",
    "最终答案格式",
    "注意：在实际操作中",
)


def _is_valid_answer(text: str) -> bool:
    """判断 LLM 回答是否为有效答案，排除非答案类回复（bash 计划、说明文本等）"""
    if not text or not text.strip():
        return False
    stripped = text.strip()
    text_lower = stripped.lower()

    for pattern in _INVALID_ANSWER_PATTERNS:
        if pattern.lower() in text_lower:
            return False

    # 超过 200 字符几乎不可能是合法 TOKEN/JSON 答案
    if len(stripped) > 200:
        return False

    for hint in _INVALID_ANSWER_HINTS:
        if hint in stripped:
            return False

    # 含有 bash 代码块标记
    if "```bash" in stripped or "```sh" in stripped:
        return False

    # 检测 {"token": "xxx"} 格式：token 值不能是说明性文本
    import re as _re
    token_match = _re.search(r'"token"\s*:\s*"([^"]*)"', stripped)
    if token_match:
        token_val = token_match.group(1)
        # token 值包含中文字符 → 无效
        if any('一' <= ch <= '鿿' for ch in token_val):
            return False
        # token 值包含换行或过长 → 无效
        if len(token_val) > 80:
            return False
        # 去掉尾部非字母数字字符后判断占位符（捕获 xxx` xxx' xxx" 等变体）
        cleaned_token = _re.sub(r'[^a-zA-Z0-9_]', '', token_val).lower()
        if cleaned_token in ("xxx", "xx", "placeholder", "token", "test", "example", "sample", "todo", "tbd"):
            return False
        if cleaned_token.startswith("xxx"):
            return False
        if "waiting" in cleaned_token or "placeholder" in cleaned_token:
            return False
        # token 值纯数字且为 0 → 无效
        if cleaned_token.isdigit() and int(cleaned_token) == 0:
            return False

    return True


def _record_skill(task_key: str, sandbox_results: list[str], answer: str, sandbox_cmd: str = "") -> None:
    """将任务经验暂存为待确认状态，下一轮无 errorCode:2 时正式写入 SKILL 库"""
    if not task_key:
        return
    _pioneer_state["pending_skill"] = {
        "task_key": task_key,
        "cmd": sandbox_cmd,
        "result": "\n".join(sandbox_results),
        "answer": answer,
    }


def _pioneer_day(
    turn: Turn,
    pioneer: Unit,
    commands: dict[int, dict[str, Any]],
) -> None:
    # 紧急治疗：血量危险时优先使用药剂，不因任务逻辑而延后
    if pioneer.health < 80 and pioneer.has_item("Medicine"):
        commands[pioneer.unit_id] = use_command("Medicine")
        return

    # 如果有已领取的任务且有phase_task描述，根据任务阶段决定行为
    if _pioneer_state["has_task"] and turn.phase_task:
        task_key = _extract_task_key(turn.phase_task)
        _pioneer_state["current_task_key"] = task_key
        phase = _pioneer_state.get("task_phase", "exploring")

        # 优先复用 SKILL 库中的已有答案（仅当答案是有效回答时）
        skill = _pioneer_state["skill_library"].get(task_key)
        if skill and skill.get("answer") and _is_valid_answer(skill["answer"]):
            commands[pioneer.unit_id] = submit_answer_command(skill["answer"])
            _pioneer_state["has_task"] = False
            _pioneer_state["task_phase"] = "idle"
            _pioneer_state["explore_cmd_count"] = 0
            _pioneer_state["sandbox_results"] = []
            return

        # 优先从沙盒结果中提取 TOKEN（./check 输出）
        for r in _pioneer_state.get("sandbox_results", []):
            token_val = _extract_token_from_result(r)
            if token_val:
                answer_json = f'{{"token": "{token_val}"}}'
                _record_skill(task_key, _pioneer_state.get("sandbox_results", []), answer_json, _pioneer_state.get("last_sandbox_cmd", ""))
                commands[pioneer.unit_id] = submit_answer_command(answer_json)
                _pioneer_state["has_task"] = False
                _pioneer_state["task_phase"] = "idle"
                _pioneer_state["explore_cmd_count"] = 0
                _pioneer_state["sandbox_results"] = []
                return

        # 有 LLM 响应时提交为答案（排除"无法执行"类无效回答）
        if turn.llm_resp and _is_valid_answer(turn.llm_resp):
            _record_skill(task_key, _pioneer_state.get("sandbox_results", []), turn.llm_resp, _pioneer_state.get("last_sandbox_cmd", ""))
            commands[pioneer.unit_id] = submit_answer_command(turn.llm_resp)
            _pioneer_state["has_task"] = False
            _pioneer_state["task_phase"] = "idle"
            _pioneer_state["explore_cmd_count"] = 0
            _pioneer_state["sandbox_results"] = []
            return

        # LLM 回答无效（如"文件不存在"）：放弃当前任务，设置冷却避免无限循环
        if turn.llm_resp and not _is_valid_answer(turn.llm_resp):
            _pioneer_state["has_task"] = False
            _pioneer_state["task_phase"] = "idle"
            _pioneer_state["explore_cmd_count"] = 0
            _pioneer_state["sandbox_results"] = []
            _pioneer_state["last_sandbox_cmd"] = ""
            _pioneer_state["task_cooldown"] = 15  # 15 回合冷却，避免立即重新接取同一任务
            # 记录该 task_key 的失败次数，超过 2 次后设置更长时间冷却
            fail_counts = _pioneer_state.get("task_fail_counts", {})
            fail_count = fail_counts.get(task_key, 0) + 1
            fail_counts[task_key] = fail_count
            _pioneer_state["task_fail_counts"] = fail_counts
            key_cd = _pioneer_state.get("task_key_cooldown", {})
            if fail_count >= 2:
                key_cd[task_key] = 50  # 50 回合内不再接取同一任务
            else:
                key_cd[task_key] = 15
            _pioneer_state["task_key_cooldown"] = key_cd
            return

        # LLM 超限后用沙盒结果作答
        if phase == "answering" and _pioneer_state.get("sandbox_results"):
            # 取最后一个沙盒结果，去掉 [exitCode:N] 前缀
            raw = _pioneer_state["sandbox_results"][-1]
            answer = raw.split("\n", 1)[-1].strip() if raw.startswith("[exitCode:") else raw.strip()
            if answer and not answer.startswith("ls ") and not answer.startswith("cat "):
                _record_skill(task_key, _pioneer_state.get("sandbox_results", []), answer, _pioneer_state.get("last_sandbox_cmd", ""))
                commands[pioneer.unit_id] = submit_answer_command(answer)
                _pioneer_state["has_task"] = False
                _pioneer_state["task_phase"] = "idle"
                _pioneer_state["explore_cmd_count"] = 0
                _pioneer_state["sandbox_results"] = []
                return

        # exploring / querying_llm 阶段：等待沙盒命令和 LLM 响应，不提交答案

    # 前往任务点领任务
    task_points = turn.task_points()
    if not task_points:
        return

    # 如果没有任务，前往任务点
    if not _pioneer_state["has_task"]:
        # 冷却期内不接取新任务
        if _pioneer_state.get("task_cooldown", 0) > 0:
            _pioneer_state["task_cooldown"] -= 1
            # 冷却期内前往任务点附近等待，但不接取
            target = _nearest(turn, pioneer.pos, task_points)
            if target is not None and distance(pioneer.pos, target) > 2:
                claimed: set[Pos] = set()
                step = _step_toward(turn, pioneer, target, claimed)
                if step is not None:
                    commands[pioneer.unit_id] = move_command(step)
            return

        # 检查当前任务描述的 task_key 是否在专属冷却中
        key_cd = _pioneer_state.get("task_key_cooldown", {})
        if key_cd:
            expired_keys = []
            for k, v in key_cd.items():
                if v > 0:
                    key_cd[k] = v - 1
                else:
                    expired_keys.append(k)
            for k in expired_keys:
                del key_cd[k]
            _pioneer_state["task_key_cooldown"] = key_cd

        # 找最近的可达任务点
        target = _nearest(turn, pioneer.pos, task_points)
        if target is None:
            return
        # 检查该任务的 task_key 是否在专属冷却中
        if turn.phase_task:
            pending_key = _extract_task_key(turn.phase_task)
            key_cd = _pioneer_state.get("task_key_cooldown", {})
            if key_cd.get(pending_key, 0) > 0:
                # 该任务还在冷却中，不接取，在附近等待
                if distance(pioneer.pos, target) > 2:
                    claimed: set[Pos] = set()
                    step = _step_toward(turn, pioneer, target, claimed)
                    if step is not None:
                        commands[pioneer.unit_id] = move_command(step)
                return
        if distance(pioneer.pos, target) <= 1:
            commands[pioneer.unit_id] = accept_task_command()
            _pioneer_state["has_task"] = True
            _pioneer_state["task_round"] = turn.round_no
            _pioneer_state["task_phase"] = "exploring"
            _pioneer_state["explore_cmd_count"] = 0
            _pioneer_state["sandbox_results"] = []
            return
        claimed: set[Pos] = set()
        step = _step_toward(turn, pioneer, target, claimed)
        if step is not None:
            commands[pioneer.unit_id] = move_command(step)
        return

    # 如果有任务但超时了，重置状态
    elapsed = turn.round_no - _pioneer_state["task_round"]
    if elapsed > 100:
        _pioneer_state["has_task"] = False
        return

    # 新增：开拓者空闲时尝试治疗和召唤宝藏
    if pioneer.unit_id not in commands:
        _pioneer_extras(turn, pioneer, commands)


def _build_task_interaction(turn: Turn) -> tuple[str, str]:
    """构造沙盒命令和 LLM prompt，返回 (executeCmd, prompt)"""
    task_desc = turn.phase_task
    if not task_desc:
        return "", ""

    phase = _pioneer_state.get("task_phase", "exploring")
    explore_count = _pioneer_state.get("explore_cmd_count", 0)
    results = _pioneer_state.get("sandbox_results", [])

    # 阶段1：探索 — 优先复用 SKILL 库
    if phase == "exploring":
        # 如果 SKILL 库中有相似任务的命令，直接复用
        task_key = _extract_task_key(task_desc)
        skill = _pioneer_state["skill_library"].get(task_key)
        if skill and skill.get("cmd") and explore_count == 0:
            _pioneer_state["explore_cmd_count"] = 1
            _pioneer_state["last_sandbox_cmd"] = skill["cmd"]
            return skill["cmd"], ""

        # 检查沙盒结果中是否已包含 TOKEN
        for r in results:
            token_match = _extract_token_from_result(r)
            if token_match:
                _pioneer_state["task_phase"] = "answering"
                return "", ""

        cmd = _build_sandbox_cmd(task_desc, explore_count, results)
        if cmd:
            _pioneer_state["explore_cmd_count"] = explore_count + 1
            _pioneer_state["last_sandbox_cmd"] = cmd
            return cmd, ""
        # 无法构造更多命令，转入 LLM 查询
        _pioneer_state["task_phase"] = "querying_llm"
        return "", ""

    # 阶段2：查询 LLM — 构造 prompt
    if phase == "querying_llm":
        if not turn.llm_resp:
            prompt = _build_llm_prompt(task_desc, results)
            if prompt:
                return "", prompt
        return "", ""

    return "", ""


def _build_sandbox_cmd(task_desc: str, explore_count: int, results: list[str]) -> str:
    """根据任务描述和已收集结果构造沙盒命令，支持多步执行（cat→cd&&cat spec.md→./check）"""
    import re

    # 检查上一轮命令是否失败
    prev_failed = False
    if results:
        last = results[-1]
        if "[exitCode:1]" in last or "No such file" in last or "Error" in last:
            prev_failed = True

    # 从任务描述中提取文件名（如 task_1_beijing.md），仅匹配 ASCII 字符
    file_patterns = re.findall(r'[a-zA-Z0-9_]+\.[a-zA-Z0-9]+', task_desc or "")
    file_patterns = [f for f in file_patterns if f not in ("python", "exitCode")]

    # 从所有沙盒结果中提取工作区路径（如 /tmp/selfEvolutionTask/.../ws_1/）
    ws_path = _extract_ws_path(results)

    # 第一轮：读取任务描述中提到的文件
    if explore_count == 0:
        if file_patterns:
            return f'cat {file_patterns[0]}'

        task_lower = task_desc.lower() if task_desc else ""
        if "http" in task_lower or "api" in task_lower or "url" in task_lower:
            urls = re.findall(r'https?://[^\s<>"]+', task_desc or "")
            if urls:
                return f'python -c "import urllib.request; print(urllib.request.urlopen(\'{urls[0]}\').read().decode())"'

        return 'pwd && ls -la'

    # 第二轮：cat 失败时用 find 搜索任务文件
    if explore_count == 1:
        if prev_failed:
            if file_patterns:
                return f'find / -name "{file_patterns[0]}" -type f 2>/dev/null'
            return 'find / -name "task_*.md" -type f 2>/dev/null'
        if results:
            last_result = results[-1]
            found_files = re.findall(r'[a-zA-Z0-9_]+\.[a-zA-Z0-9]+', last_result)
            found_files = [f for f in found_files if f not in ("python", "exitCode")]
            if found_files:
                return f'cat {found_files[0]}'
        return 'find / -name "task_*.md" -type f 2>/dev/null'

    # 第三轮：从 find 结果中提取路径并 cat
    if explore_count == 2:
        if results:
            last_result = results[-1]
            for line in last_result.split("\n"):
                line = line.strip()
                if line and not line.startswith("[exitCode") and not line.startswith("find"):
                    if "/" in line and ("." in line or not line.endswith("/")):
                        return f'cat {line}'
        return 'ls -la /home/ /tmp/ 2>/dev/null'

    # 第四轮：如果已读到任务文件且提到 spec.md，进入工作区读取 spec.md
    if explore_count == 3:
        if ws_path:
            return f'cd {ws_path} && cat spec.md'
        # ws_path 未提取到：从最近成功的 cat 结果中搜索路径
        if results:
            for r in reversed(results):
                if "[exitCode:0]" in r or "exitCode" not in r:
                    # 尝试从任务文件内容中提取 ws_ 路径
                    ws_match = re.search(r'/tmp/[\w/]+/ws_\w+', r)
                    if ws_match:
                        ws_path = ws_match.group(0).rstrip("/")
                        return f'cd {ws_path} && cat spec.md'
                    # 尝试从 "cd /xxx" 格式中提取
                    cd_match = re.search(r'cd\s+(/[^\s`]+)', r)
                    if cd_match:
                        ws_path = cd_match.group(1).rstrip("/")
                        return f'cd {ws_path} && cat spec.md'
        # 仍无路径：尝试搜索 spec.md
        return 'find / -name "spec.md" -type f 2>/dev/null | head -1'

    # 第五轮：如果已读取 spec.md，尝试运行 ./check
    if explore_count == 4:
        if ws_path:
            return f'cd {ws_path} && ./check'
        # 重新尝试从结果中提取 ws_path
        ws_path = _extract_ws_path(results)
        if ws_path:
            return f'cd {ws_path} && ./check'
        return ""

    # 第六轮：如果 ./check 输出中有 TOKEN，直接提取；否则尝试用 LLM
    if explore_count == 5:
        if ws_path:
            return f'cd {ws_path} && ./check 2>&1'
        ws_path = _extract_ws_path(results)
        if ws_path:
            return f'cd {ws_path} && ./check 2>&1'
        return ""

    return ""


def _extract_ws_path(results: list[str]) -> str | None:
    """从所有沙盒结果中提取工作区路径（如 /tmp/selfEvolutionTask/.../ws_1）"""
    import re
    for r in results:
        # 匹配 "cd /tmp/selfEvolutionTask/xxx/ws_1" 格式
        cd_match = re.search(r'cd\s+(/[^\s`]+/ws_\w+)', r)
        if cd_match:
            return cd_match.group(1).rstrip("/")
        # 匹配路径中包含 ws_ 的绝对路径
        ws_match = re.search(r'(/tmp/[\w/]+/ws_\w+)', r)
        if ws_match:
            return ws_match.group(1).rstrip("/")
        # 匹配 "cd /tmp/selfEvolutionTask/xxx" 格式
        cd_match2 = re.search(r'cd\s+(/tmp/selfEvolutionTask/[^\s`]+)', r)
        if cd_match2:
            path = cd_match2.group(1).rstrip("/")
            # 如果路径不含 ws_，尝试拼接
            if "ws_" not in path:
                ws_sub = re.search(r'ws_\w+', r)
                if ws_sub:
                    return f'{path}/{ws_sub.group(0)}'.rstrip("/")
            return path
    return None


def _extract_cities(text: str) -> list[str]:
    """从文本中提取城市名"""
    city_list = [
        "北京", "上海", "广州", "深圳", "杭州", "成都",
        "武汉", "南京", "西安", "重庆", "天津", "苏州",
    ]
    found = [city for city in city_list if city in text]
    return found


def _build_llm_prompt(task_desc: str, sandbox_results: list[str]) -> str:
    """构造提交给 LLM 的 prompt"""
    parts = []
    parts.append(f"任务描述：{task_desc}")
    if sandbox_results:
        parts.append("沙盒执行结果：")
        for i, result in enumerate(sandbox_results):
            parts.append(f"  [{i+1}] {result}")
    parts.append("请根据以上信息给出任务的答案。")
    parts.append("如果任务需要 TOKEN，请确保执行完所有步骤后从 ./check 输出中提取真实 TOKEN。")
    parts.append("答案格式为 {\"token\": \"实际token值\"}，不要返回操作步骤或说明文本。")
    return "\n".join(parts)


def _extract_token_from_result(result: str) -> str | None:
    """从沙盒执行结果中提取 TOKEN 值"""
    import re
    # 匹配 TOKEN: xxx 格式
    match = re.search(r'TOKEN:\s*(\S+)', result)
    if match:
        token_val = match.group(1).strip()
        if token_val and token_val not in ("xxx", "XXX"):
            return token_val
    # 匹配 {"token": "xxx"} 格式
    match = re.search(r'"token"\s*:\s*"([^"]+)"', result)
    if match:
        token_val = match.group(1).strip()
        if token_val and token_val not in ("xxx", "XXX", ""):
            return token_val
    return None


# ==================== 夜晚策略 ====================

def _night(turn: Turn, commands: dict[int, dict[str, Any]]) -> None:
    claimed: set[Pos] = set()
    weapons = turn.weapons()
    controllable = turn.controllable()

    if not weapons:
        # 没有武器工事，角色往基地方向退守
        station = turn.station()
        for role in controllable:
            if station is None:
                continue
            if distance(role.pos, station.pos) <= 2:
                continue
            step = _step_toward(turn, role, station.pos, claimed)
            if step is not None:
                commands[role.unit_id] = move_command(step)
        # 无武器时也尝试使用消耗品
        _night_heal(turn, commands)
        _night_extras(turn, commands)
        return

    # 紧急治疗优先于武器操作
    _night_heal(turn, commands)

    # 角色操控武器攻击
    pairs = _assign_weapon_ops(controllable, weapons, commands)
    for role, tower in pairs:
        if role.unit_id in commands:
            continue  # 已被紧急治疗分配指令
        if distance(role.pos, tower.pos) <= 1:
            # 分配的武器可用时直接操控
            if tower.cooldown <= 0:
                target = _attack_target(turn, tower)
                if target is not None:
                    commands[tower.unit_id] = attack_command(role.unit_id, target)
                    continue
            # 分配的武器不可用（冷却中/无目标）：尝试操控相邻的其他武器
            fired = False
            for other_tower in weapons:
                if other_tower.unit_id == tower.unit_id:
                    continue
                if other_tower.cooldown > 0:
                    continue
                if distance(role.pos, other_tower.pos) <= 1:
                    other_target = _attack_target(turn, other_tower)
                    if other_target is not None:
                        commands[other_tower.unit_id] = attack_command(role.unit_id, other_target)
                        fired = True
                        break
            if fired:
                continue
            # 相邻但所有武器都不可用：尝试移动到有目标可打的武器旁
            for other_tower in weapons:
                if other_tower.unit_id == tower.unit_id:
                    continue
                if other_tower.cooldown > 0:
                    continue
                other_target = _attack_target(turn, other_tower)
                if other_target is not None and distance(role.pos, other_tower.pos) > 1:
                    step = _step_toward(turn, role, other_tower.pos, claimed)
                    if step is not None:
                        commands[role.unit_id] = move_command(step)
                        break
            # 仍然无指令：走向最近的未相邻武器待命（避免完全空闲）
            if role.unit_id not in commands:
                for w in sorted(weapons, key=lambda tw: distance(role.pos, tw.pos)):
                    if distance(role.pos, w.pos) > 1:
                        step = _step_toward(turn, role, w.pos, claimed)
                        if step is not None:
                            commands[role.unit_id] = move_command(step)
                            break
            # 所有武器路径均被阻挡：尝试移向基地或拆除围墙
            if role.unit_id not in commands:
                station = turn.station()
                if station is not None:
                    step = _step_toward(turn, role, station.pos, claimed)
                    if step is not None:
                        commands[role.unit_id] = move_command(step)
            if role.unit_id not in commands:
                _try_remove_blocking_wall(turn, role, commands)
            continue
        # 未到达分配的武器：尝试移动靠近
        step = _step_toward(turn, role, tower.pos, claimed)
        if step is not None:
            commands[role.unit_id] = move_command(step)
            continue
        # 无法到达分配的武器：尝试走向最近的可达武器
        reachable_weapon = _nearest_reachable_weapon(turn, role, weapons, claimed, commands)
        if reachable_weapon is not None:
            continue
        # 无法到达任何武器：向基地方向撤退
        station = turn.station()
        if station is not None and distance(role.pos, station.pos) > 2:
            retreat = _step_toward(turn, role, station.pos, claimed)
            if retreat is not None:
                commands[role.unit_id] = move_command(retreat)
            else:
                # 撤退也失败：尝试拆除阻挡的围墙
                _try_remove_blocking_wall(turn, role, commands)

    # 未被武器操作分配的角色：走向最近武器待命或使用消耗品
    paired_ids = {role.unit_id for role, _ in pairs}
    for role in controllable:
        if role.unit_id in commands or role.unit_id in paired_ids:
            continue
        # 走向最近武器待命
        moved = False
        for w in sorted(weapons, key=lambda tw: distance(role.pos, tw.pos)):
            if distance(role.pos, w.pos) > 1:
                step = _step_toward(turn, role, w.pos, claimed)
                if step is not None:
                    commands[role.unit_id] = move_command(step)
                    moved = True
                    break
        if moved:
            continue
        # 所有武器路径均被阻挡：尝试移向基地
        station = turn.station()
        if station is not None:
            step = _step_toward(turn, role, station.pos, claimed)
            if step is not None:
                commands[role.unit_id] = move_command(step)
                continue
        # 移向基地也失败：尝试拆除阻挡的围墙
        _try_remove_blocking_wall(turn, role, commands)
        if role.unit_id in commands:
            continue
        # 拆除也失败：尝试向任意可达格子移动一步
        blocked = turn.blocked(role)
        for dx, dy in _NEIGHBOUR_STEPS:
            npos = Pos(role.pos.x + dx, role.pos.y + dy)
            if npos not in blocked and turn.land(npos) and npos not in claimed:
                commands[role.unit_id] = move_command(npos)
                claimed.add(npos)
                break

    # 未被武器操作分配的角色使用消耗品
    _night_extras(turn, commands)


def _assign_weapon_ops(
    controllable: tuple[Unit, ...],
    weapons: tuple[Unit, ...],
    commands: dict[int, dict[str, Any]] | None = None,
) -> list[tuple[Unit, Unit]]:
    """将角色分配到武器工事，每个角色只分配一座武器，每座武器只分配一个角色"""
    pairs: list[tuple[Unit, Unit]] = []
    used_roles: set[int] = set()
    used_towers: set[int] = set()

    # 优先分配已经在武器旁的角色
    for role in controllable:
        if role.unit_id in used_roles:
            continue
        if commands is not None and role.unit_id in commands:
            continue
        for tower in weapons:
            if tower.unit_id in used_towers:
                continue
            if distance(role.pos, tower.pos) <= 1:
                pairs.append((role, tower))
                used_roles.add(role.unit_id)
                used_towers.add(tower.unit_id)
                break

    # 再为剩余武器分配最近的角色
    for tower in weapons:
        if tower.unit_id in used_towers:
            continue
        best_role: Unit | None = None
        best_dist = 999
        for role in controllable:
            if role.unit_id in used_roles:
                continue
            if commands is not None and role.unit_id in commands:
                continue
            d = distance(role.pos, tower.pos)
            if d < best_dist:
                best_dist = d
                best_role = role
        if best_role is not None:
            pairs.append((best_role, tower))
            used_roles.add(best_role.unit_id)
            used_towers.add(tower.unit_id)
    return pairs


def _nearest_reachable_weapon(
    turn: Turn,
    role: Unit,
    weapons: tuple[Unit, ...],
    claimed: set[Pos],
    commands: dict[int, dict[str, Any]],
) -> Unit | None:
    """尝试走向最近的可达武器，成功时发出移动指令并返回该武器"""
    for weapon in sorted(weapons, key=lambda w: distance(role.pos, w.pos)):
        if distance(role.pos, weapon.pos) <= 1:
            continue
        step = _step_toward(turn, role, weapon.pos, claimed)
        if step is not None:
            commands[role.unit_id] = move_command(step)
            return weapon
    return None


def _attack_target(turn: Turn, tower: Unit) -> Pos | list[Pos] | None:
    reach = tower.range_of_attack()
    targets = [
        robot for robot in turn.robots
        if robot.health > 0 and distance(tower.pos, robot.pos) <= reach
    ]
    if not targets:
        return None

    # 按距离排序，优先攻击近距离高威胁目标
    targets.sort(
        key=lambda robot: (distance(tower.pos, robot.pos), -robot.health, robot.robot_id),
    )

    # 火箭发射台可攻击多个目标（等级数）
    if tower.kind == "rocket" and tower.level > 1:
        count = min(tower.level, len(targets))
        return [t.pos for t in targets[:count]]

    # 加特林可攻击多个目标（等级数），且目标须在同一90°锥形内
    if tower.kind == "gatling" and tower.level > 1:
        count = min(tower.level, len(targets))
        selected = _select_cone_targets(tower.pos, targets, count)
        if selected:
            return [t.pos for t in selected]

    # 电磁炮：只传 1 个目标位置，穿透伤害由判题器沿弹道自动计算
    if tower.kind == "railgun":
        return targets[0].pos

    return targets[0].pos


def _select_cone_targets(
    tower_pos: Pos,
    targets: list,
    max_count: int,
) -> list:
    """选择同一90°锥形内的目标"""
    if not targets:
        return []
    if len(targets) == 1 or max_count <= 1:
        return targets[:1]

    import math
    best_group: list = []
    for i, base in enumerate(targets):
        base_angle = math.atan2(
            base.pos.y - tower_pos.y, base.pos.x - tower_pos.x,
        )
        group = [base]
        for j, other in enumerate(targets):
            if j == i:
                continue
            other_angle = math.atan2(
                other.pos.y - tower_pos.y, other.pos.x - tower_pos.x,
            )
            diff = abs(base_angle - other_angle)
            diff = min(diff, 2 * math.pi - diff)
            if diff <= math.pi / 2:
                group.append(other)
            if len(group) >= max_count:
                break
        if len(group) > len(best_group):
            best_group = group[:max_count]
    return best_group


# ==================== 背包管理 ====================

# 物品价值排序（低价值优先丢弃）
_ITEM_VALUE = {
    "stone": 1,
    "iron": 2,
    "copper": 3,
    "WallFixer": 5,
    "Medicine": 5,
    "WallUpgradeVoucher1": 10,
    "WallUpgradeVoucher2": 15,
    "SmallRobotSummonOrder": 10,
    "MiddleRobotSummonOrder": 15,
    "WeaponUpgradeVoucher1": 50,
    "StationUpgradeVoucher1": 50,
    "WeaponUpgradeVoucher2": 75,
    "StationUpgradeVoucher2": 75,
    "LargeRobotSummonOrder": 50,
    "DizzyWeapon": 50,
    "Bomb": 50,
    "BossRobotSummonOrder": 100,
    "AcientTablet": 200,
    "StarSand": 200,
    "FlameBreath": 200,
    "FrostPotion": 200,
    "ThornAmulet": 200,
    "IronWhistle": 200,
}


def _drop_low_value(
    turn: Turn,
    role: Unit,
    commands: dict[int, dict[str, Any]],
) -> None:
    """背包满时丢弃最低价值的物品"""
    if not role.backpack:
        return
    # 找到背包中价值最低的物品
    lowest_item = min(
        role.backpack,
        key=lambda item: _ITEM_VALUE.get(item, 999),
    )
    # 不丢弃任务用品
    if lowest_item in TASK_ITEMS:
        # 找下一个非任务用品
        non_task = [item for item in role.backpack if item not in TASK_ITEMS]
        if non_task:
            lowest_item = min(non_task, key=lambda item: _ITEM_VALUE.get(item, 999))
        else:
            return
    commands[role.unit_id] = drop_command(lowest_item)


# ==================== 拆除围墙 ====================

def _try_remove_blocking_wall(
    turn: Turn,
    role: Unit,
    commands: dict[int, dict[str, Any]],
) -> bool:
    """检测并拆除阻挡己方移动的围墙（仅在角色被困时）"""
    walls = turn.walls()
    if not walls:
        return False

    # 检查角色是否被围墙完全包围（8方向都被堵住）
    blocked = turn.blocked(role)
    open_dirs = 0
    for dx, dy in _NEIGHBOUR_STEPS:
        npos = Pos(role.pos.x + dx, role.pos.y + dy)
        if npos not in blocked and turn.land(npos):
            open_dirs += 1

    if open_dirs > 0:
        return False  # 有可达方向，不需要拆除

    # 角色被完全包围，拆除相邻的等级最低的围墙
    adjacent_walls = [
        wall for wall in walls
        if distance(role.pos, wall.pos) <= 1
    ]
    if not adjacent_walls:
        return False

    # 拆除血量最低的围墙
    adjacent_walls.sort(key=lambda w: w.health)
    commands[role.unit_id] = remove_command(adjacent_walls[0].pos)
    return True


# ==================== 商店库存检查 ====================

def _shop_has_item(turn: Turn, item_name: str) -> bool:
    """检查武器商店是否有该商品"""
    if not turn.weapon_shop_list:
        return True  # 没有库存信息时默认可买
    return any(item.name == item_name for item in turn.weapon_shop_list)


# ==================== 辅助函数 ====================

def _count_ores(role: Unit) -> dict[str, int]:
    return {
        "stone": role.backpack.count("stone"),
        "iron": role.backpack.count("iron"),
        "copper": role.backpack.count("copper"),
    }


def _nearest(turn: Turn, origin: Pos, targets: tuple[Pos, ...]) -> Pos | None:
    if not targets:
        return None
    return min(targets, key=lambda pos: (distance(origin, pos), pos.x, pos.y))


def _adjacent_mine(turn: Turn, role: Unit) -> Pos | None:
    mines = sorted(
        (
            mine for mine in turn.stone_mines()
            if role.pos != mine and distance(role.pos, mine) <= 1
        ),
        key=lambda pos: (distance(role.pos, pos), pos.x, pos.y),
    )
    return mines[0] if mines else None


def _build_or_walk(
    turn: Turn,
    role: Unit,
    target: Pos,
    name: str,
    claimed: set[Pos],
    commands: dict[int, dict[str, Any]],
) -> None:
    if role.pos != target and distance(role.pos, target) <= 1:
        commands[role.unit_id] = build_command(target, name)
        claimed.add(target)
        return
    step = _step_toward(turn, role, target, claimed)
    if step is not None:
        commands[role.unit_id] = move_command(step)


def _step_toward(
    turn: Turn,
    role: Unit,
    target: Pos,
    claimed: set[Pos],
    *,
    inside_only: bool = False,
) -> Pos | None:
    for stand in _stand_cells(turn, role, target, claimed, inside_only):
        if stand == role.pos:
            return None
        step = next_step(turn, role, stand)
        if step is None or step in claimed:
            continue
        claimed.add(step)
        return step
    return None


def _stand_cells(
    turn: Turn,
    role: Unit,
    target: Pos,
    claimed: set[Pos],
    inside_only: bool = False,
) -> list[Pos]:
    station = turn.station()
    footprint = station_footprint(station.pos) if station else ()
    blocked = turn.blocked(role)
    cells = [
        pos for pos in _neighbours(target)
        if turn.land(pos)
        and pos not in blocked
        and (pos == role.pos or pos not in claimed)
        and (
            not inside_only
            or _footprint_distance(pos, footprint) <= 1
        )
    ]
    cells.sort(key=lambda pos: (_footprint_distance(pos, footprint), pos.x, pos.y))
    return cells


def _tower_sites(turn: Turn) -> tuple[Pos, ...]:
    station = turn.station()
    if station is None:
        return ()
    footprint = station_footprint(station.pos)
    cells = [
        pos for pos in _cells_at_distance(station.pos, 1) if turn.land(pos)
    ]
    cells.sort(key=lambda pos: (_footprint_distance(pos, footprint), pos.x, pos.y))
    return tuple(cells[:3])


def _wall_order(turn: Turn) -> tuple[Pos, ...]:
    station = turn.station()
    if station is None:
        return ()
    footprint = station_footprint(station.pos)
    xs = [pos.x for pos in footprint]
    ys = [pos.y for pos in footprint]
    xmin, xmax = min(xs), max(xs)
    ymin, ymax = min(ys), max(ys)

    # 四面围墙位置
    bottom = [Pos(x, ymin - 2) for x in range(xmax + 2, xmin - 3, -1)]   # 下侧 右→左
    left   = [Pos(xmin - 2, y) for y in range(ymax + 1, ymin - 2, -1)]   # 左侧 上→下
    top    = [Pos(x, ymax + 2) for x in range(xmin - 2, xmax + 3)]       # 上侧 左→右
    right  = [Pos(xmax + 2, y) for y in range(ymin - 1, ymax + 2)]       # 右侧 下→上

    # 根据基地在地图中的位置判断机器人进攻方向，正面围墙优先建造
    cx = turn.width / 2
    cy = turn.height / 2
    station_x = (xmin + xmax) / 2
    station_y = (ymin + ymax) / 2

    if station_x < cx and station_y > cy:
        # 基地在左上区域，机器人从基地右侧进攻，正面为右侧
        order = right + top + bottom + left
    else:
        # 基地在右下区域，机器人从基地左侧进攻，正面为左侧
        order = left + bottom + top + right

    entrance = Pos(xmax + 2, ymin - 1)
    return tuple(
        pos for pos in order if pos != entrance and turn.land(pos)
    )


def _cells_at_distance(station_pos: Pos, radius: int) -> tuple[Pos, ...]:
    footprint = station_footprint(station_pos)
    xs = [pos.x for pos in footprint]
    ys = [pos.y for pos in footprint]
    cells = []
    for x in range(min(xs) - radius, max(xs) + radius + 1):
        for y in range(min(ys) - radius, max(ys) + radius + 1):
            pos = Pos(x, y)
            if pos in footprint:
                continue
            if _footprint_distance(pos, footprint) == radius:
                cells.append(pos)
    return tuple(cells)


def _footprint_distance(pos: Pos, footprint: tuple[Pos, ...]) -> int:
    if not footprint:
        return 0
    return min(distance(pos, cell) for cell in footprint)


def _neighbours(pos: Pos) -> tuple[Pos, ...]:
    return tuple(
        Pos(pos.x + dx, pos.y + dy) for dx, dy in _NEIGHBOUR_STEPS
    )
