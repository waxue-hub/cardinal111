"""Protocol and immutable game-state models for the Future War agent.

The judge sends a fairly wide JSON document.  Keeping the decoding in one
place is important: the planner should never have to guess whether a missing
field means ``0``, an empty list, or an unavailable piece of information.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable, Mapping

DAY_ROUNDS = 70
NIGHT_ROUNDS = 60
ROUNDS_PER_DAY = DAY_ROUNDS + NIGHT_ROUNDS
MAX_ROUNDS = 1300

WEAPON_BUILD_COST = 25
WALL_MATERIAL = "stone"
ORE_TYPES = ("stone", "iron", "copper")
LAND = "land"
STATION = "station"
WALL = "wall"
WORKER = "worker"
PIONEER = "pioneer"
TOWER_TYPES = ("gatling", "railgun", "rocket")
HERO_TYPES = (WORKER, PIONEER)

TOWER_RANGE_BY_LEVEL = {
    "gatling": (3, 5, 7),
    "railgun": (6, 8, 10),
    "rocket": (10, 15, 10**9),
}

MAX_HEALTH_BY_KIND = {
    STATION: (1500, 3000, 4500),
    "gatling": (1000, 1500, 2000),
    "railgun": (1000, 1500, 2000),
    "rocket": (1000, 1500, 2000),
    WALL: (1000, 1500, 2000),
    PIONEER: (200,),
    WORKER: (220,),
}

ROBOT_SCORE = {
    "smallRobot": 1,
    "middleRobot": 2,
    "largeRobot": 4,
    "bossRobot": 10,
}

SHOP_PRICES = {
    "WeaponUpgradeVoucher1": 100,
    "WallUpgradeVoucher1": 20,
    "StationUpgradeVoucher1": 100,
    "WeaponUpgradeVoucher2": 150,
    "WallUpgradeVoucher2": 30,
    "StationUpgradeVoucher2": 150,
    "WallFixer": 10,
    "Medicine": 10,
    "DizzyWeapon": 100,
    "Bomb": 100,
    "SmallRobotSummonOrder": 20,
    "MiddleRobotSummonOrder": 30,
    "LargeRobotSummonOrder": 100,
    "BossRobotSummonOrder": 200,
    "AcientTablet": 15,
    "StarSand": 15,
    "FlameBreath": 15,
    "FrostPotion": 15,
    "ThornAmulet": 15,
    "IronWhistle": 15,
}

TASK_POINT_TYPES = {
    "challenger": ("challengerTaskPoint1", "challengerTaskPoint2"),
    "defender": ("defenderTaskPoint1", "defenderTaskPoint2"),
}


@dataclass(frozen=True)
class Pos:
    x: int
    y: int

    @classmethod
    def load(cls, raw: Any) -> "Pos":
        if isinstance(raw, Pos):
            return raw
        if not isinstance(raw, Mapping):
            raise ValueError(f"invalid position: {raw!r}")
        return cls(int(raw["x"]), int(raw["y"]))

    def dump(self) -> dict[str, int]:
        return {"x": self.x, "y": self.y}


def distance(first: Pos, second: Pos) -> int:
    """Chebyshev distance, as required by the game rules."""

    return max(abs(first.x - second.x), abs(first.y - second.y))


def station_footprint(pos: Pos) -> tuple[Pos, ...]:
    # The API gives the station's upper-left cell.  The map origin is at the
    # lower-left, hence the two cells with y - 1.
    return (
        pos,
        Pos(pos.x + 1, pos.y),
        Pos(pos.x, pos.y - 1),
        Pos(pos.x + 1, pos.y - 1),
    )


@dataclass(frozen=True)
class Unit:
    unit_id: int
    pos: Pos
    kind: str
    health: int
    level: int
    cooldown: int
    attack_range: int
    capacity: int | None
    backpack: tuple[str, ...]

    @classmethod
    def load(cls, raw: Mapping[str, Any]) -> "Unit":
        raw_capacity = raw.get("backPackCapability")
        raw_id = raw.get("id", 0)
        return cls(
            int(raw_id),
            Pos.load(raw["pos"]),
            str(raw.get("roleType", "unknown")),
            int(raw.get("health") or 0),
            int(raw.get("level") or 0),
            int(raw.get("cooldown") or 0),
            int(raw.get("attackRange") or 0),
            int(raw_capacity) if raw_capacity is not None else None,
            tuple(str(item) for item in raw.get("backpack") or ()),
        )

    @property
    def alive(self) -> bool:
        return self.health > 0

    @property
    def backpack_full(self) -> bool:
        return self.capacity is not None and len(self.backpack) >= self.capacity

    def count(self, item: str) -> int:
        return self.backpack.count(item)

    def max_health(self) -> int:
        values = MAX_HEALTH_BY_KIND.get(self.kind, (0,))
        index = min(max(self.level, 1), len(values)) - 1
        return values[index]

    def range_of_attack(self) -> int:
        if self.attack_range > 0:
            return self.attack_range
        table = TOWER_RANGE_BY_LEVEL.get(self.kind)
        if table is None:
            return 0
        level = min(max(self.level, 1), len(table))
        return table[level - 1]


@dataclass(frozen=True)
class Robot:
    robot_id: int
    pos: Pos
    health: int
    role_type: str = "smallRobot"
    abnormal_state: str = ""
    target_team: str = ""

    @classmethod
    def load(cls, raw: Mapping[str, Any]) -> "Robot":
        return cls(
            int(raw.get("id", 0)),
            Pos.load(raw["pos"]),
            int(raw.get("health") or 0),
            str(raw.get("roleType") or "smallRobot"),
            str(raw.get("abnormalState") or ""),
            str(raw.get("targetTeam") or ""),
        )


@dataclass(frozen=True)
class TaskInfo:
    task_type: str
    position: Pos
    cooldown: int
    score_reward: int
    gold_reward: int
    valid: bool
    timeout_rounds: int

    @classmethod
    def load(cls, raw: Mapping[str, Any]) -> "TaskInfo":
        return cls(
            str(raw.get("taskType") or ""),
            Pos.load(raw["taskPosition"]),
            int(raw.get("coldDownRounds") or 0),
            int(raw.get("scoreReward") or 0),
            int(raw.get("goldReward") or 0),
            bool(raw.get("isValid", False)),
            int(raw.get("timeoutRounds") or 0),
        )


@dataclass(frozen=True)
class ShopItem:
    name: str
    price: int

    @classmethod
    def load(cls, raw: Any) -> "ShopItem":
        if isinstance(raw, str):
            return cls(raw, SHOP_PRICES.get(raw, 0))
        name = str(raw.get("name") or "")
        price = raw.get("price")
        return cls(name, int(price if price is not None else SHOP_PRICES.get(name, 0)))


@dataclass(frozen=True)
class WorldNews:
    official: str = ""
    folk: str = ""

    @classmethod
    def load(cls, raw: Any) -> "WorldNews":
        if not isinstance(raw, Mapping):
            return cls()
        return cls(
            str(raw.get("officialNews") or ""),
            str(raw.get("folkLegends") or ""),
        )


@dataclass(frozen=True)
class Turn:
    round_no: int
    is_day: bool
    team_type: str
    team_id: str
    gold: int
    score: int
    width: int
    height: int
    zones: dict[Pos, str]
    ours: tuple[Unit, ...]
    enemies: tuple[Unit, ...]
    robots: tuple[Robot, ...]
    tasks: tuple[TaskInfo, ...]
    phase_task: str
    last_action_results: dict[int, bool]
    last_treasure_result: int
    llm_resp: str
    news: WorldNews
    vendor_prices: dict[str, int]
    weapon_shop: tuple[ShopItem, ...]
    errors: tuple[dict[str, Any], ...]

    @classmethod
    def load(cls, payload: Mapping[str, Any]) -> "Turn":
        round_no = int(payload.get("roundNo") or 1)
        info = payload.get("mapInfo") or {}
        team = payload.get("teamOur") or {}
        raw_results = payload.get("lastRoundRoleActionResults") or {}
        vendor: dict[str, int] = {}
        for item in payload.get("vendorShopList") or ():
            if isinstance(item, Mapping):
                name = str(item.get("name") or item.get("type") or "")
                if name:
                    vendor[name] = int(item.get("price") or 0)
        return cls(
            round_no,
            (round_no - 1) % ROUNDS_PER_DAY < DAY_ROUNDS,
            str(team.get("type") or ""),
            str(team.get("teamId") or ""),
            int(team.get("goldNum") or 0),
            int(team.get("totalScore") or 0),
            int(info.get("width") or 41),
            int(info.get("height") or 32),
            {
                Pos.load(zone["pos"]): str(zone.get("neutralType") or "")
                for zone in info.get("zones") or ()
                if isinstance(zone, Mapping) and zone.get("pos") is not None
            },
            tuple(Unit.load(role) for role in team.get("roles") or ()),
            tuple(Unit.load(role) for role in (payload.get("teamEnemy") or {}).get("roles") or ()),
            tuple(
                Robot.load(robot)
                for robot in (payload.get("robot") or {}).get("roles") or ()
            ),
            tuple(TaskInfo.load(task) for task in team.get("playerTasks") or ()),
            str(payload.get("phaseTask") or ""),
            {int(key): bool(value) for key, value in raw_results.items()},
            int(payload.get("lastSummonTreasureResult") or 0),
            str(payload.get("llmResp") or ""),
            WorldNews.load(payload.get("worldNews")),
            vendor,
            tuple(ShopItem.load(item) for item in payload.get("weaponShopList") or ()),
            tuple(item for item in payload.get("errors") or () if isinstance(item, Mapping)),
        )

    def station(self) -> Unit | None:
        return next((unit for unit in self.ours if unit.kind == STATION), None)

    def find(self, unit_id: int) -> Unit | None:
        return next((unit for unit in self.ours if unit.unit_id == unit_id), None)

    def alive(self, kinds: tuple[str, ...], *, include_dead: bool = False) -> tuple[Unit, ...]:
        return tuple(
            unit for unit in self.ours
            if unit.kind in kinds and (include_dead or unit.alive)
        )

    def controllable(self) -> tuple[Unit, ...]:
        return tuple(sorted(self.alive(HERO_TYPES), key=lambda unit: unit.unit_id))

    def workers(self) -> tuple[Unit, ...]:
        return tuple(sorted(self.alive((WORKER,)), key=lambda unit: unit.unit_id))

    def pioneers(self) -> tuple[Unit, ...]:
        return tuple(sorted(self.alive((PIONEER,)), key=lambda unit: unit.unit_id))

    def weapons(self) -> tuple[Unit, ...]:
        return tuple(sorted(self.alive(TOWER_TYPES), key=lambda unit: unit.unit_id))

    def walls(self) -> tuple[Unit, ...]:
        return tuple(sorted(self.alive((WALL,)), key=lambda unit: unit.unit_id))

    def footprint(self, unit: Unit) -> tuple[Pos, ...]:
        return station_footprint(unit.pos) if unit.kind == STATION else (unit.pos,)

    def neutral_positions(self, *kinds: str) -> tuple[Pos, ...]:
        wanted = set(kinds)
        return tuple(pos for pos, kind in self.zones.items() if kind in wanted)

    def resource_mines(self, resource: str | None = None) -> tuple[Pos, ...]:
        wanted = {resource} if resource else set(ORE_TYPES)
        return tuple(pos for pos, kind in self.zones.items() if kind in wanted)

    def own_task_points(self) -> tuple[Pos, ...]:
        kinds = TASK_POINT_TYPES.get(self.team_type, ())
        return self.neutral_positions(*kinds)

    def land(self, pos: Pos) -> bool:
        return (
            0 <= pos.x < self.width
            and 0 <= pos.y < self.height
            and self.zones.get(pos, LAND) == LAND
        )

    def occupied_cells(self, *, include_enemies: bool = True) -> frozenset[Pos]:
        cells: set[Pos] = set()
        for unit in self.ours:
            if unit.alive:
                cells.update(self.footprint(unit))
        if include_enemies:
            for unit in self.enemies:
                if unit.alive:
                    cells.update(self.footprint(unit))
        return frozenset(cells)

    def blocked(self, moving: Unit | None = None) -> frozenset[Pos]:
        cells = {pos for pos, kind in self.zones.items() if kind != LAND}
        cells.update(self.occupied_cells())
        if moving is not None:
            cells.difference_update(self.footprint(moving))
        cells.update(robot.pos for robot in self.robots if robot.health > 0)
        return frozenset(cells)

    def at_distance_one(self, target: Pos) -> tuple[Pos, ...]:
        return tuple(
            Pos(target.x + dx, target.y + dy)
            for dx, dy in (
                (-1, -1), (-1, 0), (-1, 1), (0, -1),
                (0, 1), (1, -1), (1, 0), (1, 1),
            )
        )


def _targets(positions: Iterable[Pos]) -> list[dict[str, int]]:
    return [pos.dump() for pos in positions]


def move_command(pos: Pos) -> dict[str, Any]:
    return {"action": "move", "targetPos": _targets((pos,))}


def collect_command(pos: Pos) -> dict[str, Any]:
    return {"action": "collect", "targetPos": _targets((pos,))}


def build_command(pos: Pos, name: str) -> dict[str, Any]:
    return {"action": "build", "targetPos": _targets((pos,)), "name": name}


def remove_command(pos: Pos) -> dict[str, Any]:
    return {"action": "remove", "targetPos": _targets((pos,))}


def attack_command(controller_id: int, positions: Iterable[Pos]) -> dict[str, Any]:
    return {
        "action": "attack",
        "targetPos": _targets(positions),
        "controllerId": str(controller_id),
    }


def use_command(name: str, target: Pos | None = None) -> dict[str, Any]:
    command: dict[str, Any] = {"action": "use", "name": name}
    if target is not None:
        command["targetPos"] = _targets((target,))
    return command


def sell_command(name: str, number: int) -> dict[str, Any]:
    return {"action": "sell", "name": name, "num": max(1, int(number))}


def buy_command(name: str, number: int = 1) -> dict[str, Any]:
    return {"action": "buy", "name": name, "num": max(1, int(number))}


def accept_task_command() -> dict[str, Any]:
    return {"action": "acceptTask"}


def submit_answer_command(answer: str) -> dict[str, Any]:
    return {"action": "submitAnswer", "taskAnswer": answer}


def summon_treasure_command(pos: Pos, items: Iterable[str]) -> dict[str, Any]:
    return {
        "action": "summonTreasure",
        "targetPos": _targets((pos,)),
        "item": list(items),
    }


def drop_command(name: str) -> dict[str, Any]:
    return {"action": "drop", "name": name}
